package com.vdocipher.aegis.player.internal;

/**
 * Debug flags.
 */

public final class DebugFlags {
    public static final boolean LOGS_ENABLED = false;
}
