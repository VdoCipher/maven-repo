package com.vdocipher.aegis.clipstat;

public final class ApiUrls {
    private static final String CREATE_API_URL = "https://clipstat.com/api/v2/";

    private static final String PATCH_API_URL = CREATE_API_URL + "update/"; // + ":session"

    static String getCreateApiUrl() {
        return CREATE_API_URL;
    }

    static String getPatchApiUrl() {
        return PATCH_API_URL;
    }
}
